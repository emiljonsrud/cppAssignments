#pragma once
#include "std_lib_facilities.h"
#include "Card.h"
#include "SixDeck.h"
#include "Hand.h"
#include "Options.h"
#include "Blackjack.h"

void playBlackjack();