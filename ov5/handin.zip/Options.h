#pragma once
enum class Option {
    hit = 1,
    hold = 2,
    doubleDown = 3,
    split = 4
};